# WhatsApp Chat Export: Nurul Shahira 
Export date: August 26, 2026 at 8:01 PM

---

## August 26, 2026

[8:06 AM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[8:06 AM] **You:** Hello, good morning

[8:12 AM] **Nurul Shahira :** Yes, Good morning

[8:32 AM] **You:** Hi, I’m Rajeev. I got your contact from the police officer regarding the traffic accident involving our cars.

I understand that both vehicles have some damage, and the officer mentioned that we could try to resolve the matter between ourselves if possible.

I’m happy to discuss this calmly and see if we can reach a mutually acceptable solution. Could you please share some photos/details of the damage to your vehicle, and we can take it from there.

Thank you.

[8:34 AM] **Nurul Shahira :** Hi Rajeev , I'm Shahira

[8:35 AM] **Nurul Shahira :** Wait i share you some photos

[8:37 AM] **Nurul Shahira :** [album message]

[8:37 AM] **Nurul Shahira :** [Image]

[8:37 AM] **Nurul Shahira :** [Video]

[8:37 AM] **Nurul Shahira :** [Image]

[8:37 AM] **Nurul Shahira :** [unknown message]

[8:37 AM] **Nurul Shahira :** [unknown message]

[8:37 AM] **Nurul Shahira :** [unknown message]

[8:43 AM] **Nurul Shahira :** As shown in the photos I’ve sent, the damage to my car includes the right-side door, rear fender, rear bumper, and right rear sport rim. These damages are also stated in the police report that I have already made.

I’m open to discussing this between ourselves and hopefully we can come to a fair and mutually acceptable solution. Just for clarification, at the time of the accident, I had already stopped by the side of the road, but when I was about to reach the other vehicle, it had already moved off.

Please let me know how you would like to proceed. Thank you.

[8:48 AM] **You:** Will reply soon. Let me reach office

[10:01 AM] **You:** [album message]

[10:01 AM] **You:** [Image] Thank you for sharing the details. I understand the areas of damage you have mentioned and appreciate the clarification.

As both of us have made police reports, I think it would be best for us to keep the discussion focused on the damage and see if we can reach a fair and mutually acceptable solution, without making any assumptions regarding responsibility at this stage.

Could you please share the repair estimate or quotation once available? I can then review it and we can discuss how best to proceed.

Also let me share my car damage, repair cost estimate from honda is too high but noramal workshop asking ~RM500

Thank you.

[10:01 AM] **You:** [Image]

[10:46 AM] **Nurul Shahira :**
> _You: [album]_
Hi Rajeev, I’ve checked with Perodua regarding the repair cost, and they provided an official quotation of RM2,176.20, including SST. The quotation covers the repair and refitting of the affected right-side doors, rear right quarter panel and rear right bumper.

I also checked with a normal workshop, and their estimated cost is around RM2,000.

I understand that both vehicles have been damaged, and I appreciate that we are both trying to resolve this matter amicably. From my understanding of the situation, however, I was travelling on the main road at the time, and the contact was with the side/rear area of my car when your vehicle was coming from the junction.

I hope you can understand my position as well. I’m happy to cooperate and discuss this calmly, and hopefully we can come to a fair way of resolving the matter based on the actual damage and repair costs.

I’ve attached the Perodua quotation for your reference. Thank you.

[10:46 AM] **Nurul Shahira :** [Forwarded] Knock and spray
-front right door
-rear right door
-rear right quarter panel
-rear right bumper(touchup)
Rm2000, 3-4days

[10:46 AM] **Nurul Shahira :**
> _Nurul Shahira : Knock and spray
-front right door
-rear right door
-rear right quarter panel
-rear right bumper(touchup)
Rm2000, 3-4days_
This is from normal workshop

[10:47 AM] **Nurul Shahira :** [Image]

[10:47 AM] **Nurul Shahira :** this is from perodua

[3:00 PM] **You:**
> _Nurul Shahira : Hi Rajeev, I’ve checked with Perodua regarding the repair cost, and they provided an official quotation of RM2,176.20, including SST. The quotation covers the repair and refitting of the affected right-side doors, rear right quarter panel and rear right bumper.

I also checked with a normal workshop, and their estimated cost is around RM2,000.

I understand that both vehicles have been damaged, and I appreciate that we are both trying to resolve this matter amicably. From my understanding of the situation, however, I was travelling on the main road at the time, and the contact was with the side/rear area of my car when your vehicle was coming from the junction.

I hope you can understand my position as well. I’m happy to cooperate and discuss this calmly, and hopefully we can come to a fair way of resolving the matter based on the actual damage and repair costs.

I’ve attached the Perodua quotation for your reference. Thank you._
I checked with my known workshop in OUG. He says around 750 and would take around 2days time

[6:34 PM] **Nurul Shahira :**
> _You: I checked with my known workshop in OUG. He says around 750 and would take around 2days time_
I understand that you have your own workshop that you are familiar with, but I have decided to send my car to a workshop that I trust and have been using for a long time, and it is also much more convenient as it is near my home.

I have also given sufficient time for you to contact me regarding this matter since the accident on 8 July. As such, I would prefer to proceed with the workshop of my choice rather than sending my car to a workshop recommended by you.

I hope you can respect my decision and we can proceed accordingly.

[6:35 PM] **Nurul Shahira :** Perodua has inspected my car and provided an official quotation of RM2,176.20, including SST.

I will send my car to a workshop that I trust and have been using for a long time, which is also near my home. I am not comfortable sending it to a workshop I am unfamiliar with, especially when your workshop’s estimated cost of RM750 is significantly different from Perodua’s official quotation.

I hope you can respect my decision.

[7:39 PM] **Nurul Shahira :** The accident happened on 8 July 2026, and I have already given sufficient time for you to contact me regarding this matter. I also made a police report and went to the hospital on the same day for an X-ray after hitting my head and experiencing dizziness.

Perodua has inspected my car and provided an official quotation of RM2,176.20, including SST. The quotation from the workshop I usually use is also around the same amount, so I am not sure how your workshop came up with an estimate of only RM750.

I will proceed with the workshop that I trust and have been using for a long time, which is also near my home.

If you do not agree with the quotation or my choice of workshop, I will contact the police officer handling the case and proceed with the proper police and insurance claim process.

[7:55 PM] **You:** Hi Shahira, I understand your position and I respect your preference to use a workshop that you are comfortable with.

My intention in sharing the RM750 estimate was only to provide an alternative repair option, as the difference from the Perodua quotation is quite significant. I am not refusing to cooperate or resolve the matter.

Since both of us have already made police reports, I think it would be best to let the police/insurance process determine the appropriate way forward, including the repair cost and responsibility, rather than have any misunderstanding between us.

I will also inform the investigating officer that we have discussed the matter and that we were unable to reach an agreement on the repair cost.

I’m happy to cooperate fully with the proper process. Thank you.


The workshop i recommend is not bad - can see customers review

https://share.google/d67XKUNhrxLMxV8wb

[7:56 PM] **You:** sorry i just back from office
